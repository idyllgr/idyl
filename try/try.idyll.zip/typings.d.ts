declare var lightGallery: any;
